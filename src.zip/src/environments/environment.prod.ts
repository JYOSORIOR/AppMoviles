export const environment = {
  production: true,
  apiKey: 'AIzaSyDjwvcUH0nmv9bAWJARmCboGSic42kbhbg',
};
