//export const URL_SERVICIOS = "https://www.magxapp.com/rest/index.php/Magx";
//export const URL_SERVICIOS = "http://192.168.10.21:3000";
//export const URL_SERVICIOS = "http://localhost:3000";

export const URL_SERVICIOS = "https://appmovilees-production.up.railway.app/api";
